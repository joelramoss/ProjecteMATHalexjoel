using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParallaxEffect : MonoBehaviour
{
    public Transform[] fondos;          // Array de capas/fondos
    public float[] parallaxScales;      // Array de factores de parallax para cada fondo
    public float speed = 1f;            // Velocidad de desplazamiento autom�tico de la capa

    private float[] startPos;           // Array de posiciones iniciales en X de cada fondo
    private float[] lengths;            // Array de anchos de cada fondo

    void Start()
    {
        // Inicializar arrays de tama�o igual al n�mero de fondos
        startPos = new float[fondos.Length];
        lengths = new float[fondos.Length];

        // Guardar la posici�n inicial y el tama�o de cada fondo
        for (int i = 0; i < fondos.Length; i++)
        {
            startPos[i] = fondos[i].position.x;
            lengths[i] = fondos[i].GetComponent<SpriteRenderer>().bounds.size.x;
        }
    }

    void Update()
    {
        // Aplicar el efecto parallax y repetici�n para cada fondo
        for (int i = 0; i < fondos.Length; i++)
        {
            // Calcular la nueva posici�n basado en el tiempo transcurrido y la velocidad
            float dist = (Time.time * speed) * parallaxScales[i];

            // Mover el fondo en el eje X
            fondos[i].position = new Vector3(startPos[i] - dist, fondos[i].position.y, fondos[i].position.z);

            // Repetir el fondo si llega al final (se ha movido m�s de su propio ancho)
            if (fondos[i].position.x < startPos[i] - lengths[i])
            {
                startPos[i] -= lengths[i];  // Ajustar la posici�n inicial para repetir el fondo
            }
        }
    }
}
